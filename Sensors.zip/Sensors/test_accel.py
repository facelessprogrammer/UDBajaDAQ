import time
import board
import busio
import adafruit_mma8451
import adafruit_tca9548a
from datetime import date
from datetime import datetime
import pandas as pd

i2c = busio.I2C(board.SCL, board.SDA)
#time.sleep(1)
tca = adafruit_tca9548a.TCA9548A(i2c)
sensor = adafruit_mma8451.MMA8451(tca[4], address=0x1d)

# Optionally change the range from its default of +/- 4G:
#sensor.range = adafruit_mma8451.RANGE_2G
#sensor.range = adafruit_mma8451.RANGE_4G
#sensor.range = adafruit_mma8451.RANGE_8G

# Optionally change the data rate from its default of 800hz:
#sensor.data_rate = adafruit_mma8451.DATARATE_800HZ
#sensor.data_rate = adafruit_mma8451.DATARATE_400HZ
#sensor.data_rate = adafruit_mma8451.DATARATE_200HZ
#sensor.data_rate = adafruit_mma8451.DATARATE_100HZ
#sensor.data_rate = adafruit_mma8451.DATARATE_50HZ
#sensor.data_rate = adafruit_mma8451.DATARATE_12_5HZ
#sensor.data_rate = adafruit_mma8451.DATARATE_6_25HZ
#sensor.data_rate = adafruit_mma8451.DATARATE_1_56HZ

x_accel = []
y_accel = []
z_accel = []
date_array = []
time_array = []
array = []
loop = True;
# Loop to print acceleration and orientation every second
while loop:
	x, y, z, = sensor.acceleration
	#print("Acceleration: x={0:0.3f}m/s^2  y={1:0.3f}m/s^2 z={2:0.3f}m/s^2".format(x, y, z))

	orientation = sensor.orientation
	# Orientation is one of these values:
	# - PL_PUF: Portrait, up, front
	# - PL_PUB: Portrait, up, back
	# - PL_PDF: Portrait, down, front
	# - PL_PDB: Portrait, down, back
	# - PL_LRF: Landscape, right, front
	# - PL_LRB: Landscape, right, back
	# - PL_LLF: Landscape, left, front
	# - PL_LLB: Landscape, left, back

	#print("Orientation: ", end = "")
	#if orientation == adafruit_mma8451.PL_PUF:
		#print("Portrait, up, front")
	#elif orientation == adafruit_mma8451.PL_PUB:
		#print("Portrait, up, back")
	#elif orientation == adafruit_mma8451.PL_PDF:
		#print("Portrait, down, front")
	#elif orientation == adafruit_mma8451.PL_PDB:
		#print("Portrait, down, back")
	#elif orientation == adafruit_mma8451.PL_LRF:
		#print("Landscape, right, front")
	#elif orientation == adafruit_mma8451.PL_LRB:
		#print("Landscape, right, back")
	#elif orientation == adafruit_mma8451.PL_LLF:
		#print("Landscape, left, front")
	#elif orientation == adafruit_mma8451.PL_LLB:
		#print("Landscape, left, back")

	today = date.today()
	now = datetime.now()
	formatted_date = today.strftime('%B %d, %Y')
	formatted_time = now.strftime('%H:%M:%S')

	x_accel.append(x)
	y_accel.append(y)
	z_accel.append(z)
	date_array.append(formatted_date)
	time_array.append(formatted_time)

	array = pd.DataFrame(
		{
			"Date": date_array,
			"Time": time_array,
			"X Value": x_accel,
			"Y Value": y_accel,
			"Z Value": z_accel,
		})
	print(array)

	final = array.to_csv('test_accel.csv')

	#time.sleep(1.0)
