import time
import datetime
from datetime import date
from datetime import datetime
import pandas as pd
#import RPi.GPIO as GPIO
import board
import digitalio

fuel_sensor = digitalio.DigitalInOut(board.D6)
fuel_sensor.direction = digitalio.Direction.INPUT
fuel_sensor.pull = digitalio.Pull.DOWN

#GPIO.setmode(GPIO.BOARD)
#inpt = 6
#GPIO.setup(inpt, GPIO.IN)

#count = 0
#while count < 10:
#	print(GPIO.input(16))
#	count = count + 1
#	time.sleep(0.1)

tot_cnt = 0
constant = 0.006

# MAIN
#print('Water Flow - Approximate ', str(time.asctime(time.localtime(time.time()))))
#rpt_int = int(input('Input desired report interval in seconds: '))
#print('Reports every ', rpt_int, ' seconds')
#print('Control C to exit')

date_array = []
time_array = []
fuel_rate = []
fuel_tot = []

while True:
	rate_cnt = 0
	io_last = not fuel_sensor.value
	start_time = time.time()
	while time.time() - start_time <= 1:
		io_cur = fuel_sensor.value

		if io_cur != io_last:
			rate_cnt += 1

		io_last = io_cur

	tot_cnt += rate_cnt

	today = date.today()
	now = datetime.now()
	formatted_date = today.strftime('%B %d, %Y')
	formatted_time = now.strftime('%H:%M:%S')
	date_array.append(formatted_date)
	time_array.append(formatted_time)

	LperM = round(rate_cnt * constant, 4)
	TotLit = round(tot_cnt * constant, 4)

	fuel_rate.append(LperM)
	fuel_tot.append(TotLit)

	array = pd.DataFrame(
		{
			"Date": date_array,
			"Time": time_array,
			"Fuel Flow": fuel_rate,
			"Total Fuel": fuel_tot,
		})
	print(array)

	final = array.to_csv('test_fuel.csv')

	#print('\nLiters / min ', LperM, '(', rpt_int, 'second sample)')
	#print('Total Liters ', TotLit)
	#print('Time (min & clock) ', minutes, '\t', time.asctime(time.localtime(time.time())), '\n')
	time.sleep(0.05)

GPIO.cleanup()
print('Done')
