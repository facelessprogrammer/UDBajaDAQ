import time
import board
import digitalio

switch = digitalio.DigitalInOut(board.D25)
switch.direction = digitalio.Direction.INPUT

led1 = digitalio.DigitalInOut(board.D20)
led1.direction = digitalio.Direction.OUTPUT

led2 = digitalio.DigitalInOut(board.D26)
led2.direction = digitalio.Direction.OUTPUT

while True:
	time.sleep(0.1)
	try:
		led1.value = True

		while switch.value:
			led2.value = True

		led2.value = False

	except KeyboardInterrupt:
		led1.value = False

