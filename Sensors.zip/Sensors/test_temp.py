import board
import busio
import adafruit_mcp9808
import time
i2c = board.I2C()
mcp = adafruit_mcp9808.MCP9808(i2c, address=0x18)
while True:
	tempC = mcp.temperature
	tempF = tempC * 9 / 5 + 32
	print('Temperature: {} degrees C {} degrees F'.format(tempC,tempF))
	time.sleep(0.2)

