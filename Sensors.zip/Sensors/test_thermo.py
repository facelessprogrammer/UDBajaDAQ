import time
import board
import digitalio
import adafruit_max31855
from datetime import date
from datetime import datetime
import pandas as pd

spi = board.SPI()
cs = digitalio.DigitalInOut(board.D8)

max31855 = adafruit_max31855.MAX31855(spi, cs)
date_array = []
time_array = []
tempC_array = []
tempF_array = []
loop = True
counter = 0

try:
	while loop:

		counter += 1
		today = date.today()
		now = datetime.now()
		formatted_date = today.strftime('%B %d, %Y')
		formatted_time = now.strftime('%H:%M:%S')
		date_array.append(formatted_date)
		time_array.append(formatted_time)

		tempC = max31855.temperature
		tempF = tempC * 9/5 + 32
		tempC_array.append(tempC)
		tempF_array.append(tempF)

		array = pd.DataFrame(
			{
				"Date": date_array,
				"Time": time_array,
				"Temperature (C)": tempC_array,
				"Temperature (F)": tempF_array,
			})
		print(array)

		final = array.to_csv('test_thermo.csv')

		#time.sleep(0.1)

except RuntimeError:
	tempC = max31855.temperature


